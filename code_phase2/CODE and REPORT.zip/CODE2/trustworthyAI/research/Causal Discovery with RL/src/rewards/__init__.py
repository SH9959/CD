from .Reward_BIC import get_Reward
#from .Reward_by_HSIC_multiprocessing import getReward_HSIC