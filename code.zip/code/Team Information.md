**Team Name:** SCIR-DT

**Member Table:**

| Serial Number | User (Codalab) | Email                 | Phone Number (Optional) | Affiliation                    |
| ------------- | -------------- | --------------------- | ----------------------- | ------------------------------ |
| 1             | SH9959         | 1572958043@qq.com     | 17305069959             | Harbin Institute of Technology |
| 2             | MIngdali       | mdli@ir.hit.edu.cn    | 13076886717             | Harbin Institute of Technology |
| 3             | XinyiWang      | w1958002973@gmail.com |                         | Harbin Institute of Technology |
| 4             | chenyifan-scir | yfchen@ir.hit.edu.cn  | 13972934654             | Harbin Institute of Technology |
| 5             | WangJiZhe      | 2907274904@qq.com     | 13848593165             | Harbin Institute of Technology |