The baseline for Track 1 of the PCIC 2022 competition.  
The method used originates from the paper "[Time series domain adaptation via sparse associative structure alignment](https://arxiv.org/abs/2012.11797)".

You can design more complicated methods based on this foundational code.
